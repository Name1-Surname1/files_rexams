# 1) Escoger el folder desde donde se ejecutará pdflatex
library(rstudioapi)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
sep <- ifelse(.Platform$OS.type == "windows", ";", ":")
Sys.setenv(
  TEXINPUTS = paste0(
    getwd(),
    sep,
    Sys.getenv("TEXINPUTS")
  )
)

# 2) Cargar la librería exams
library(exams)

# 3) Ver algunos ejemplos
exams2pdf("Rlogo.Rmd")
exams2pdf("regression.Rmd")

# 4) Generar nuestros propios exámenes
cantidad <- 1
width    <- nchar(as.character(cantidad))
ids      <- paste0("ID-", formatC(1:cantidad, width  = width, flag   = "0"))

#   a) Exámenes con solución
set.seed(2025)
unlink("examenes_con_solucion", recursive = TRUE)
dir.create("examenes_con_solucion")
for (i in 1:cantidad){
  exams2pdf(c("ejercicio1_con_solucion.Rmd", "ejercicio2_con_solucion.Rmd"),
            n        = 1,
            name     = paste0("Examen_con_solucion_", ids[i], "_"),
            header   = list(ID = ids[i]),
            dir      = "examenes_con_solucion",
            template = "plain_personalizado.tex",
            edir     = ".")
}

#   b) Exámenes sin solución
set.seed(2025)
unlink("examenes_sin_solucion", recursive = TRUE)
dir.create("examenes_sin_solucion")
for (i in 1:cantidad){
  exams2pdf(c("ejercicio1_sin_solucion.Rmd", "ejercicio2_sin_solucion.Rmd"),
            n        = 1,
            name     = paste0("Examen_sin_solucion_", ids[i], "_"),
            header   = list(ID = ids[i]),
            dir      = "examenes_sin_solucion",
            template = "plain_personalizado.tex",
            edir     = ".")
}

# 5) Instalar y cargar pdftools
if (!require("pdftools")) install.packages("pdftools")
library(pdftools)

# 6) Lista todos los PDFs de los folders
pdfs_con <- list.files("examenes_con_solucion", full.names = TRUE)
pdfs_sin <- list.files("examenes_sin_solucion", full.names = TRUE)

# 7) Generar único PDF con soluciones y sin soluciones
unlink("final_con_soluciones", recursive = TRUE)
unlink("final_sin_soluciones", recursive = TRUE)
dir.create("final_con_soluciones")
dir.create("final_sin_soluciones")
pdf_combine(input  = pdfs_con, output = "final_con_soluciones/final_con_sol.pdf")
pdf_combine(input  = pdfs_sin, output = "final_sin_soluciones/final_sin_sol.pdf")
