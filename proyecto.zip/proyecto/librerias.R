# 1) Instalar exams
if(!require("exams"))install.packages("exams")

# 2) Para ejecutar pdflatex desde el folder de trabajo
if(!require("rstudioapi"))install.packages("rstudioapi")

# 3) Instalar pdftools
if(!require("pdftools"))install.packages("pdftools")

# 4) Instalar plot3D
if(!require("plot3D"))install.packages("plot3D")

# 5) Instalar tinytex (con soporte para español)
tinytex::install_tinytex()
tinytex::tlmgr_install(c("babel-spanish", "hyphen-spanish"))
tinytex::tlmgr_update()