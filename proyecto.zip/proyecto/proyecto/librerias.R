# 1) Instalar tinytex (con soporte para español)
tinytex::install_tinytex()
tinytex::tlmgr_install(c("babel-spanish", "hyphen-spanish"))
tinytex::tlmgr_update()

# 2) Instalar exams
install.packages("exams")

# 3) Para ejecutar pdflatex desde el folder de trabajo
if(!require(tinytex))install.packages("rstudioapi")